package com.itheima.ui;

import com.itheima.bean.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class LoginUI extends JFrame implements  ActionListener{
    private JTextField loginNameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    //定义一个静态的集合，存储系统重全部的用户对象信息
    private static ArrayList<User> allUsers = new ArrayList<>();
    //初始化几个测试的用户对象信息作为登录用，用静态代码块
    static {
        allUsers.add(new User("超级管理员", "123456", "admin"));
        allUsers.add(new User("董名喆", "123456", "dmz"));
    }

    public LoginUI() {
        setTitle("登录界面");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // 系统标题
        JLabel systemTitle = new JLabel("青峰公司人事管理系统");
        systemTitle.setFont(new Font("微软雅黑", Font.BOLD, 18));
        systemTitle.setForeground(new Color(0, 102, 153));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 5, 25, 5);
        mainPanel.add(systemTitle, gbc);

        gbc.insets = new Insets(5, 5, 5, 5);

        // 用户名标签和输入框
        JLabel usernameLabel = new JLabel("用户名:");
        usernameLabel.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        loginNameField = new JTextField(15);
        loginNameField.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(usernameLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 5, 5, 5);
        mainPanel.add(loginNameField, gbc);

        // 密码标签和输入框
        JLabel passwordLabel = new JLabel("密码:");
        passwordLabel.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        passwordField = new JPasswordField(15);
        passwordField.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(passwordLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 5, 5, 5);
        mainPanel.add(passwordField, gbc);

        // 登录按钮
        loginButton = new JButton("登录");
        loginButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
        loginButton.setBackground(new Color(0, 120, 215));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.addActionListener(this);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(10, 15, 5, 5); // 增大左侧间距
        mainPanel.add(loginButton, gbc);

        // 注册按钮
        registerButton = new JButton("注册");
        registerButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
        registerButton.setBackground(new Color(240, 240, 240));
        registerButton.setForeground(Color.BLACK);
        registerButton.setFocusPainted(false);
        registerButton.addActionListener(this);
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(10, 15, 5, 5); // 增大左侧间距
        mainPanel.add(registerButton, gbc);

        add(mainPanel);
        setVisible(true);
    }


    public static void main(String[] args) {
        new LoginUI();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // 这里可能是登录按钮点击过来的，也可能是注册按钮点击过来的
        // 判断到底是登录还是注册按钮点击的
        // 需要强转为JButton，因为正常返回是Object，除了按钮外，还可能是图片等其他对象
        JButton btn = (JButton) e.getSource();
        if (e.getSource() == loginButton) {
            System.out.println("登录");
            login();
        } else {
            System.out.println("注册");
        }
    }

    private void login() {
        String loginName = loginNameField.getText();
        String password = new String(passwordField.getPassword());
        User user = getUserByLoginName(loginName);
        if (user != null) {
            if (user.getPassword().equals(password)) {
                System.out.println("登录成功");
                new EmployeeManagementUI(user.getUsername());
                this.dispose();
            }
        } else {
            JOptionPane.showMessageDialog(this, "密码错误");
        }
    }

    private User getUserByLoginName(String loginName) {
        for (User user : allUsers) {
            if (user.getLoginName().equals(loginName)) {
                return user;
            }
        }
        return null;
    }
}