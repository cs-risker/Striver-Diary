package com.itheima.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import com.itheima.bean.*;

public class EmployeeManagementUI extends JFrame{
    private JTextField inputField;
    private JButton searchButton, addButton;
    private JTable table;
    private DefaultTableModel tableModel;
    private List<Employee> employees = new ArrayList<>();
    private static String username;

    public EmployeeManagementUI() {

    }

    public EmployeeManagementUI(String username) {
        this.username = username;
        initComponents();
        initTable();
        addDataToTable();
        addListeners();
        this.setVisible(true);
    }

    private void initComponents() {
        setTitle("员工信息管理界面；当前用户：" + username);
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        inputField = new JTextField(20);
        searchButton = new JButton("搜索");
        addButton = new JButton("添加");

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        topPanel.add(inputField);
        topPanel.add(searchButton);
        topPanel.add(addButton);

        add(topPanel, BorderLayout.NORTH);
    }

    private void initTable() {
        String[] columnNames = {"ID", "姓名", "性别", "年龄", "职位"};
        // 创建不可编辑的表格模型
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 所有单元格都不可编辑
            }
        };
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }

    private void addDataToTable() {
        Employee employee0 = new Employee(0, "李克志", "男", 58, "北七");
        employees.add(employee0);
        tableModel.addRow(new Object[]{employee0.getID(), employee0.getName(),
                employee0.getSex(), employee0.getAge(), employee0.getPosition()});
        Employee employee1 = new Employee(1, "赵培元", "男", 61, "北七");
        employees.add(employee1);
        tableModel.addRow(new Object[]{employee1.getID(), employee1.getName(),
                employee1.getSex(), employee1.getAge(), employee1.getPosition()});
    }

    private void addListeners() {
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String searchText = inputField.getText();
                System.out.println("搜索内容: " + searchText);
            }
        });

        //单独为按钮绑定监听器（实际上也可以把整个窗口当作监听器，像LoginUI.java）
        //简化前
//        addButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                JOptionPane.showMessageDialog(EmployeeManagementUI.this, "添加功能待实现");
//            }
//        });
        //用lambda简化后
        addButton.addActionListener(e -> {
            //弹出一个添加员工信息的界面出来
            new AddEmployeeUI(this);
        });

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getButton() == MouseEvent.BUTTON3) {
                    int row = table.rowAtPoint(e.getPoint());
                    table.setRowSelectionInterval(row, row);
                    showContextMenu(e);
                }
            }
        });
    }

    private void showContextMenu(MouseEvent e) {
        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem editMenuItem = new JMenuItem("修改");
        JMenuItem deleteMenuItem = new JMenuItem("删除");

        editMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(EmployeeManagementUI.this, "修改功能待实现");
            }
        });

        deleteMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
//                JOptionPane.showMessageDialog(EmployeeManagementUI.this, "删除 ID：" + selectedRow);
                if (selectedRow != -1) {
                    tableModel.removeRow(selectedRow);
                    employees.remove(selectedRow);
                }
            }
        });

        popupMenu.add(editMenuItem);
        popupMenu.add(deleteMenuItem);
        popupMenu.show(e.getComponent(), e.getX(), e.getY());
    }



    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new EmployeeManagementUI("test");
        });
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
        tableModel.addRow(new Object[]{employee.getID(), employee.getName(),
                employee.getSex(), employee.getAge(), employee.getPosition()});
    }
}

