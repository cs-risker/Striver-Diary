package com.itheima.ui;

import com.itheima.bean.Employee;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddEmployeeUI extends JFrame {

    private JTextField idField;
    private JTextField nameField;
    private JComboBox<String> genderComboBox;
    private JTextField ageField;
    private JTextField positionField;
    EmployeeManagementUI employeeManagementUI;

    public AddEmployeeUI() {

    }

    public AddEmployeeUI(EmployeeManagementUI employeeManagementUI) {
        this.employeeManagementUI = employeeManagementUI;
        setTitle("添加员工信息");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // ID 标签和输入框
        JLabel idLabel = new JLabel("ID:");
        idField = new JTextField(10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        mainPanel.add(idLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        mainPanel.add(idField, gbc);

        // 姓名标签和输入框
        JLabel nameLabel = new JLabel("姓名:");
        nameField = new JTextField(10);
        gbc.gridx = 0;
        gbc.gridy = 1;
        mainPanel.add(nameLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        mainPanel.add(nameField, gbc);

        // 性别标签和下拉框
        JLabel genderLabel = new JLabel("性别:");
        String[] genders = {"男", "女"};
        genderComboBox = new JComboBox<>(genders);
        gbc.gridx = 0;
        gbc.gridy = 2;
        mainPanel.add(genderLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        mainPanel.add(genderComboBox, gbc);

        // 年龄标签和输入框
        JLabel ageLabel = new JLabel("年龄:");
        ageField = new JTextField(10);
        gbc.gridx = 0;
        gbc.gridy = 3;
        mainPanel.add(ageLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 3;
        mainPanel.add(ageField, gbc);

        // 职位标签和输入框
        JLabel positionLabel = new JLabel("职位:");
        positionField = new JTextField(10);
        gbc.gridx = 0;
        gbc.gridy = 4;
        mainPanel.add(positionLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 4;
        mainPanel.add(positionField, gbc);

        // 添加按钮
        JButton addButton = new JButton("添加");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = idField.getText();
                String name = nameField.getText();
                String gender = (String) genderComboBox.getSelectedItem();
                String age = ageField.getText();
                String position = positionField.getText();

                // 这里可以添加数据验证逻辑，例如检查输入是否为空等
                // 简单打印获取到的员工信息
                System.out.println("添加员工：ID=" + id + ", 姓名=" + name + ", 性别=" + gender + ", 年龄=" + age + ", 职位=" + position);

                // 关闭当前窗口
                dispose();
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 5;
        mainPanel.add(addButton, gbc);

        //给添加员工信息绑定一个点击事件监听器
        addButton.addActionListener(e -> {
            Employee employee = new Employee();
            employee.setID(Integer.parseInt(idField.getText()));
            employee.setName(nameField.getText());
            employee.setSex((String)genderComboBox.getSelectedItem());
            employee.setAge(Integer.parseInt(ageField.getText()));
            employee.setPosition(positionField.getText());
            //把这个员工对象送到信息界面那里去，添加到信息界面集合中，并在信息界面中展示
            employeeManagementUI.addEmployee(employee);
            JOptionPane.showMessageDialog(this,"添加成功");
            this.dispose();
        });

        // 取消按钮
        JButton cancelButton = new JButton("取消");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        gbc.gridx = 1;
        gbc.gridy = 5;
        mainPanel.add(cancelButton, gbc);

        add(mainPanel);
        setVisible(true);
    }

    public static void main(String[] args) {
        new AddEmployeeUI();
    }
}