import  com.itheima.ui.*;

public class App {
    public static void main(String[] args) {
        new LoginUI();
    }
}
